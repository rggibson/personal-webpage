/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;
import java.io.*;

/**
 *
 * @author Owner
 */
public class ScheduleParse
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException
    {
        // The file to parse
        String inputFileName = "games.lp";
        String outputFileName = "parsedGames.lp";

        Scanner scan = null;
        try
        {
            scan = new Scanner(new File(inputFileName));
        }
        catch(Exception e)
        {

        }

        // Skip to the first game in the file
        String game;
        do
        {
            game = scan.next();
        }
        while (!game.contains("game"));

        String s = "";
        for ( ; game.contains("game"); game = scan.next())
        {
            s += game + ".\n";
        }

        scan.close();


        // Write to file
        PrintWriter pen = new PrintWriter(new File(outputFileName));
        pen.println(s);
        pen.close();
    }

}
