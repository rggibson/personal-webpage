/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.Scanner;
import java.util.Hashtable;
import java.io.*;

/**
 *
 * @author Owner
 */
public class ScheduleViewer
{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException
    {
        // The file to parse
        String inputFileName = "matchups.lp";
        String outputFileName = "latex-matchups.tex";
        final int MAX_DAY = 35; // We ignore all games past this day

        Scanner scan = null;
        try
        {
            scan = new Scanner(new File(inputFileName));
        }
        catch(Exception e)
        {

        }

        // Skip to the first matchup in the file
        String matchup;
        do
        {
            matchup = scan.next();
        }
        while (!matchup.contains("matchup"));

        // Map teams to indices
        Hashtable table = new Hashtable();
        Hashtable inverseTable = new Hashtable();
        int nextTeamIndex = 1;

        // First run through, we map teams to indices
        for ( ; matchup.contains("matchup"); matchup = scan.next())
        {
            String awayTeam = matchup.substring(8, 11);
            String homeTeam = matchup.substring(12, 15);

            if (!table.containsKey(awayTeam))
            {
                table.put(awayTeam, nextTeamIndex);
                inverseTable.put(nextTeamIndex++, awayTeam);
            }
            if (!table.containsKey(homeTeam))
            {
                table.put(homeTeam, nextTeamIndex);
                inverseTable.put(nextTeamIndex++, homeTeam);
            }
        }

        scan.close();
        Scanner scan2 = null;

        try
        {
            scan2 = new Scanner(new File(inputFileName));
        }
        catch(Exception e)
        {

        }

        // Skip to the first matchup in the file
        do
        {
            matchup = scan2.next();
        }
        while (!matchup.contains("matchup"));

        // Next run through, we record the games in an array for each team
        int[][][] games = new int[table.size() + 1][MAX_DAY + 1][2];
        for ( ; matchup.contains("matchup"); matchup = scan2.next())
        {
            String awayTeam = matchup.substring(8, 11);
            String homeTeam = matchup.substring(12, 15);
            String dayString = matchup.substring(16, matchup.length() - 1);
            int day = Integer.parseInt(dayString);

		if (day > MAX_DAY)
		{
			continue;
		}

            int awayTeamIndex = (Integer)table.get(awayTeam);
            int homeTeamIndex = (Integer)table.get(homeTeam);

            assert(games[awayTeamIndex][day][0] == 0);
            assert(games[homeTeamIndex][day][0] == 0);

            games[awayTeamIndex][day][0] = homeTeamIndex;
            games[awayTeamIndex][day][1] = 0; // Away game
            games[homeTeamIndex][day][0] = awayTeamIndex;
            games[homeTeamIndex][day][1] = 1; // Home game
        }

        String s = "\\documentclass{beamer}\n";
        s += "\\usepackage{array}\n";
        s += "\\usepackage{colortbl}\n";
        s += "\\usepackage{multirow}\n";

        s += "\\mode<presentation>\n";
        s += "{\n";
        s += "\t\\usetheme{Madrid}\n";
        s += "\t\\useinnertheme{circles}\n";
        s += "}";

        s += "\\begin{document}\n";

        // Now it is time to create the frame for each team
        for (int teamIndex = 1; teamIndex < nextTeamIndex; ++teamIndex)
        {
            s += "\\begin{frame}\n";
            s += "\t\\frametitle{" + (String)inverseTable.get(teamIndex) + "}\n";
            s += "\t\\begin{center}\n";
            s += "\t\t\\begin{tabular}{|p{0.5in}|p{0.5in}|p{0.5in}|p{0.5in}|p{0.5in}|p{0.5in}|p{0.5in}|}\n";
            s += "\t\t\t\\hline\n";
            for (int day = 1; day <= MAX_DAY; ++day)
            {
                if (day % 7 == 1)
                {
                    s += "\t\t\t";
                }

                if (games[teamIndex][day][0] == 0)
                {
                    // No game on this day
                    s += "\\tiny{" + day + "} ";
                    s += "\\includegraphics[scale=1]{blank.png} ";
                }
                else
                {
                    // Game on this day.  First, determine cell color
                    if (games[teamIndex][day][1] == 0)
                    {
                        // Away game
                        s += "\\cellcolor{blue} ";
                    }
                    else
                    {
                        // Home game
                        s += "\\cellcolor{red} ";
                    }
                    s += "\\tiny{" + day + "} ";
                    s += "\\includegraphics[scale=0.6]{" + (String)inverseTable.get(games[teamIndex][day][0]) + ".png} ";
                }

                if (day % 7 != 0)
                {
                    s += "& ";
                }
                else
                {
                    s += "\\\\\n\t\t\t\\hline\n";
                }
            }

            s += "\t\t\\end{tabular}\n";
            s += "\t\\end{center}\n";
            s += "\\end{frame}\n\n\n";
        }

        s += "\\end{document}\n";

        // Write to file
        PrintWriter pen = new PrintWriter(new File(outputFileName));
        pen.println(s);
        pen.close();
    }

}
